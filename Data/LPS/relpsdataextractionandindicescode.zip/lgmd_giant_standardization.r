
#setwd('L:/Bluefin/BFT_2019/USRR_CPUE/')
setwd('C:/users/matthew.lauretta/desktop/USRR/')

#dat1=read.csv('L:/HMS data/LPS/LPS_20190322/compiled_data/lgmd_giant_bft_analysis_9301.csv')
#dat2=read.csv('L:/HMS data/LPS/LPS_20190322/compiled_data/lgmd_giant_bft_analysis_0218.csv')
dat1=read.csv('L:/HMS data/LPS/LPS_20200225/compiled_data/lgmd_giant_bft_analysis_9301.csv')
dat2=read.csv('lgmd_giant_bft_analysis_0219.csv')

dat1$id=dat1$ID
dat1$year=dat1$YEAR
dat1$month=dat1$MONTH
dat1$fhours=dat1$HOURS
dat1$giant_bft=dat1$LARGEC
dat1$large_med_bft=dat1$LGMEDC
dat1$stcode=ifelse(dat1$STATE=="CT",9,
	ifelse(dat1$STATE=="MA",25,
	ifelse(dat1$STATE=="ME",23,
	ifelse(dat1$STATE=="NH",33,
	ifelse(dat1$STATE=="NJ",34,
	ifelse(dat1$STATE=="NY",36,
	ifelse(dat1$STATE=="RI",44,
	ifelse(dat1$STATE=="VA",51,"NA"))))))))

lps=merge(dat1,dat2,all.x=TRUE,all.y=TRUE)
head(lps)

library(glmmADMB)
library(emmeans)

lps$BFT=lps$large_med_bft+lps$giant_bft
lps$success=ifelse(lps$BFT>0,1,0)
lps$cpue=lps$BFT/lps$fhours
lps$fYear=as.factor(lps$year)
lps$fMonth=as.factor(lps$month)
lps$fState=as.factor(lps$stcode)
#lps$bait=as.factor(paste0(lps$bt_live,lps$bt_art,lps$bt_dead))
#lps$gear=paste0(lps$fm_troll,lps$fm_chunk,lps$fm_chum,lps$fm_other)
#lps$bimonth=as.factor(cut(lps$month,c(0,2,4,6,8,10,12,14)))
#lps$lat=as.numeric(substr(lps$latddmm,1,2))
#lps$lon=as.numeric(substr(lps$londdmm,1,2))
#lps$Area_5x5=paste0(trunc(lps$lon/5)*5,"_",trunc(lps$lat/5)*5)

final_glm=glm.nb(BFT~fYear+fMonth+offset(log(fhours)),data=lps)
summary(final_glm)
lsm=emmeans(final_glm,~fYear,type="response")
lsm

ppos=aggregate(success~year,data=lps,mean)
plot(ppos,type='b',pch=16,ylim=c(0,1))
nominal=aggregate(cpue~year,data=lps,mean)
plot(1993:2019,nominal[,2]/mean(nominal[,2]),pch=16,ylim=c(0,4),xlab="Year",ylab="Index",main="USA_RR_BFT_>177cm")

index=summary(lsm)$response/mean(summary(lsm)$response)
index_CV=summary(lsm)$SE/summary(lsm)$response
upper_CL=summary(lsm)$asymp.UCL/mean(summary(lsm)$response)
lower_CL=summary(lsm)$asymp.LCL/mean(summary(lsm)$response)
polygon(x=c(1993:2019,2019:1993),y=c(upper_CL,rev(lower_CL)),col=rgb(0,0,0,0.25),border=0)
lines(1993:2019,index,lwd=2,col=1)
index2017=c(0.61,	0.79,	0.97,	3.09,	1.23,	1.29,	1.75,	0.51,	1.19,	2.32,	0.52,	0.73,	0.63,
	0.38,	0.31,	0.38,	0.55,	1.24,	0.84,	0.76,	0.43,	0.58,	0.91,	1.06,	1.93)
lines(1993:2017,index2017/mean(index2017),col=1,lwd=2,lty=2)
legend("topright",c("2018_index","2020_analysis"),col=c(1,1),lwd=c(2,2),lty=c(2,1))
write.csv(cbind(ppos,obs_cpue=nominal[,2]/mean(nominal[,2]),index,index_CV,lower_CL,upper_CL),'lgmed_giant_index.csv')

