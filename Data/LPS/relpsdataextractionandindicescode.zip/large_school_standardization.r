
#setwd('L:/Bluefin/BFT_2019/USRR_CPUE/')
setwd('C:/users/matthew.lauretta/desktop/USRR/')


dat1=read.csv('L:/HMS data/LPS/LPS_20200225/compiled_data/large_school_bft_analysis_9301.csv')
dat2=read.csv('large_school_bft_analysis_0219.csv')

dat1$id=dat1$ID
dat1$year=dat1$YEAR
dat1$month=dat1$MONTH
dat1$fhours=dat1$HOURS
dat1$large_school_bft=dat1$LGSCHC
dat1$stcode=ifelse(dat1$STATE=="CT",9,
	ifelse(dat1$STATE=="DE",10,
	ifelse(dat1$STATE=="MA",25,
	ifelse(dat1$STATE=="MD",24,
	ifelse(dat1$STATE=="NJ",34,
	ifelse(dat1$STATE=="NY",36,
	ifelse(dat1$STATE=="RI",44,
	ifelse(dat1$STATE=="VA",51,"NA"))))))))

lps=merge(dat1,dat2,all.x=TRUE,all.y=TRUE)
head(lps)

library(glmmADMB)
library(emmeans)
library(bbmle)

lps$BFT=lps$large_school_bft
lps$success=ifelse(lps$BFT>0,1,0)
lps$cpue=lps$BFT/lps$fhours
lps$fYear=as.factor(lps$year)
lps$fMonth=as.factor(lps$month)
lps$fState=as.factor(lps$stcode)
#lps$bait=paste0(lps$bt_live,lps$bt_art,lps$bt_dead)
#lps$gear=paste0(lps$fm_troll,lps$fm_chunk,lps$fm_chum,lps$fm_other)
#lps$Bimonth=as.factor(cut(lps$month,c(0,2,4,6,8,10,12,14)))
#lps$lat=as.numeric(substr(lps$latddmm,1,2))
#lps$lon=as.numeric(substr(lps$londdmm,1,2))
#lps$Area_5x5=paste0(trunc(lps$lon/5)*5,"_",trunc(lps$lat/5)*5)

table(lps$year,lps$STATE)

ppos=aggregate(success~year,data=lps,mean)
plot(ppos,typ='b',pch=16,ylim=c(0,1))

final_glm=glm.nb(BFT~fYear+fMonth+fState+offset(log(fhours)),data=lps)
summary(final_glm)
lsm=emmeans(final_glm,~fYear,type="response")
lsm



nominal=aggregate(cpue~year,data=lps,mean)
plot(1993:2019,nominal[,2]/mean(nominal[,2]),pch=15,ylim=c(0,4),xlab="Year",ylab="Index",main="USA_RR_BFT_115_144cm")
index=summary(lsm)$response/mean(summary(lsm)$response)
index_CV=summary(lsm)$SE/summary(lsm)$response
upper_CL=summary(lsm)$asymp.UCL/mean(summary(lsm)$response)
lower_CL=summary(lsm)$asymp.LCL/mean(summary(lsm)$response)
polygon(x=c(1993:2019,2019:1993),y=c(upper_CL,rev(lower_CL)),col=rgb(0,0,0,0.2),border=0)
lines(1993:2019,index,lwd=2,col=1)
index2017=c(2.70,0.59,1.02,	1.39,	0.22,	0.81,	1.32,	1.04,	2.06,	2.28,	0.82,	0.68,	0.65,	1.11,	0.96,
	1.46,	0.35,	1.03,	0.61,	0.57,	1.26,	0.48,	0.22,	0.72,	0.61)
lines(1993:2017,index2017/mean(index2017),col=1,lty=2,lwd=2)
legend("topright",c("2018_index","2020_analysis"),col=c(1,1),lwd=c(2,2),lty=c(2,1))

write.csv(cbind(ppos,obs_cpue=nominal[,2]/mean(nominal[,2]),index,index_CV,lower_CL,upper_CL),'large_school_index.csv')

