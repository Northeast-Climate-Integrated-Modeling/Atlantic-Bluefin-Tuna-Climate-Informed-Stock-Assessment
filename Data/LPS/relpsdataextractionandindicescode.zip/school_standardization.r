
#setwd('C:/users/matthew.lauretta/desktop/USRR_CPUE/')
setwd('C:/users/matthew.lauretta/desktop/USRR/')

dat1=read.csv('L:/HMS data/LPS/LPS_20200225/compiled_data/school_bft_analysis_9301.csv')
dat2=read.csv('school_bft_analysis_0219.csv')

dat1$id=dat1$ID
dat1$year=dat1$YEAR
dat1$month=dat1$MONTH
dat1$fhours=dat1$HOURS
dat1$school_bft=dat1$SCHOOLC
dat1$stcode=ifelse(dat1$STATE=="CT",9,
	ifelse(dat1$STATE=="DE",10,
	ifelse(dat1$STATE=="MA",25,
	ifelse(dat1$STATE=="MD",24,
	ifelse(dat1$STATE=="NJ",34,
	ifelse(dat1$STATE=="NY",36,
	ifelse(dat1$STATE=="RI",44,
	ifelse(dat1$STATE=="VA",51,"NA"))))))))

lps=merge(dat1,dat2,all.x=TRUE,all.y=TRUE)
head(lps)

lps$region=ifelse(lps$year<2002,as.character(lps$region),
	ifelse(lps$stcode%in%c(23,33,25,44,9,36,34),"north",
		ifelse(lps$stcode%in%c(24,10,51),"south","NA")))

lps$closure=NA
lps$closure[lps$year<2002]=as.character(lps$opcl_ssm[lps$year<2002])
lps$closure[lps$year==2002]=ifelse(lps$month[lps$year==2002]==6&lps$day[lps$year==2002]%in%c(1:14),"closed","open")
lps$closure[lps$year==2003]="open"
lps$closure[lps$year==2004]="open"
lps$closure[lps$year==2005]=ifelse(lps$month[lps$year==2005]>9,"closed","open")
lps$closure[lps$year==2006&lps$month<7]="closed"
lps$closure[lps$year==2006&lps$month>6&lps$region=="south"]=
	ifelse(lps$month[lps$year==2006&lps$month>6&lps$region=="south"]==7&
		lps$day[lps$year==2006&lps$month>6&lps$region=="south"]%in%c(1:21),"open","closed")
lps$closure[lps$year==2006&lps$month>6&lps$region=="north"]=
	ifelse(lps$month[lps$year==2006&lps$month>6&lps$region=="north"]==8&
		lps$day[lps$year==2006&lps$month>6&lps$region=="north"]%in%c(25:31),"open",
			ifelse(lps$month[lps$year==2006&lps$month>6&lps$region=="north"]==9&
				lps$day[lps$year==2006&lps$month>6&lps$region=="north"]<15,"open","closed"))
lps$closure[lps$year==2007]="open"
lps$closure[lps$year==2008]="open"
lps$closure[lps$year==2009]="open"
lps$closure[lps$year==2010]="open"
lps$closure[lps$year==2011]="open"
lps$closure[lps$year==2012]="open"
lps$closure[lps$year==2013]="open"
lps$closure[lps$year==2014]="open"
lps$closure[lps$year==2015]="open"
lps$closure[lps$year==2016]="open"
lps$closure[lps$year==2017]="open"
lps$closure[lps$year==2018]="open"
lps$closure[lps$year==2019]="open"

head(lps)
lps2=subset(lps,closure!="closed")

library(glmmADMB)
library(emmeans)
library(bbmle)

lps2$BFT=lps2$school_bft
lps2$success=ifelse(lps2$BFT>0,1,0)
lps2$cpue=lps2$BFT/lps2$fhours
lps2$fYear=as.factor(lps2$year)
lps2$fMonth=as.factor(lps2$month)
lps2$fState=as.factor(lps2$stcode)
#lps2$bait=paste0(lps2$bt_live,lps2$bt_art,lps2$bt_dead)
#lps2$gear=paste0(lps2$fm_troll,lps2$fm_chunk,lps2$fm_chum,lps2$fm_other)
#lps2$Bimonth=as.factor(cut(lps2$month,c(0,2,4,6,8,10,12,14)))
#lps2$lat=as.numeric(substr(lps2$latddmm,1,2))
#lps2$lon=as.numeric(substr(lps2$londdmm,1,2))
#lps2$Area_5x5=paste0(trunc(lps2$lon/5)*5,"_",trunc(lps2$lat/5)*5)

final_glm=glm.nb(BFT~fYear+fMonth+offset(log(fhours)),data=lps2)
summary(final_glm)
lsm=emmeans(final_glm,~fYear,type="response")
lsm

ppos=aggregate(success~year,data=lps2,mean)
plot(ppos,typ='b',pch=16,ylim=c(0,1))
nominal=aggregate(cpue~year,data=lps2,mean)
plot(1993:2019,nominal[,2]/mean(nominal[,2]),pch=15,ylim=c(0,5),xlab="Year",ylab="Index",main="USA_RR_BFT_66_114cm")

index=summary(lsm)$response/mean(summary(lsm)$response)
index_CV=summary(lsm)$SE/summary(lsm)$response
upper_CL=summary(lsm)$asymp.UCL/mean(summary(lsm)$response)
lower_CL=summary(lsm)$asymp.LCL/mean(summary(lsm)$response)
polygon(x=c(1993:2019,2019:1993),y=c(upper_CL,rev(lower_CL)),col=rgb(0,0,0,0.2),border=0)
lines(1993:2019,index,lwd=2,col=1)
index2017=c(1.67,	0.32,	1.53,	1.85,	3.55,	1.35,	1.43,	1.01,	0.57,	1.02,	0.63,	2.41,	2.08,
	0.55,	0.52,	0.35,	0.29,	0.52,	0.59,	0.47,	0.60,	0.47,	0.32,	0.35,	0.55)
lines(1993:2017,index2017/mean(index2017),col=1,lty=2,lwd=2)
legend("topright",c("2017_index","2020 _analysis"),col=c(1,1),lwd=c(2,2),lty=c(2,1))
write.csv(cbind(ppos,obs_cpue=nominal[,2]/mean(nominal[,2]),index,index_CV,lower_CL,upper_CL),'school_index.csv')

